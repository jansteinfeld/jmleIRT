library(testthat)
library(jmleIRT)
test_check("jmleIRT")
